# Media Store — Website

Lightweight static site (Arabic + English). Content lives in `content/site.json` and is edited from the dashboard at `/admin/`. The Instagram section pulls your latest posts automatically.

## Files that matter
- `index.html`, `assets/site.css`, `assets/site.js` — the site
- `content/site.json` — all text, images, projects (EN + AR)
- `admin/` — dashboard (Decap CMS)
- `netlify/functions/` + `netlify/lib/` — Instagram auto-feed
- `package.json`, `netlify.toml`

Old version (safe to delete): `sections/`, `components/`, `data/`, `app.jsx`, `tweaks-panel.jsx`, `design-canvas.jsx`, `index-v1.html`, `wireframes/`, `wireframes.html`, `uploads/`.

## 1. Deploy
1. Upload this folder to a GitHub repo.
2. Netlify → Add new site → Import from Git → pick the repo. Build command: empty. Publish directory: `.`

## 2. Instagram auto-feed (latest posts + views, likes, saves)
Requirements: @mediastore.agency must be a **Business or Creator** account.
1. developers.facebook.com → My Apps → Create app → type "Business".
2. Add product **Instagram** → "API setup with Instagram login".
3. Add the @mediastore.agency account and click **Generate token**. Copy it.
4. Netlify → Site configuration → Environment variables → add `IG_TOKEN` = the token.
5. Redeploy. Open `https://YOUR-SITE.netlify.app/api/instagram` — you should see your posts as JSON.

After that:
- Posts and stats refresh automatically every 7 days.
- The token renews itself on each refresh (never expires as long as the site is live).
- Instagram video links expire, so they're re-signed every 2 days in the background.
- Optional: `IG_LIMIT` env variable = how many posts to show (default 12).

Until the token is added, the section falls back to the links in the dashboard ("Instagram (backup only)").

## 3. Dashboard
1. In `admin/config.yml`, replace `YOUR-GITHUB-USERNAME/YOUR-REPO`, commit.
2. GitHub → Settings → Developer settings → OAuth Apps → New. Homepage: your Netlify URL. Callback: `https://api.netlify.com/auth/done`.
3. Netlify → Site configuration → Access & security → OAuth → Install provider → GitHub → paste Client ID + Secret.
4. Open `/admin/` → Login with GitHub. Every "Publish" updates the site in ~30 seconds.

## SEO (Banha / بنها)
Already in the site: title + description targeting "marketing agency in Banha / شركة تسويق في بنها", local business schema (address, map point, hours, phones), robots.txt, sitemap.xml.
- Domain used everywhere: `https://mediastore.agency`. If your domain is different, replace it in `index.html`, `robots.txt`, `sitemap.xml`.
- Google Search Console → add your domain → submit `/sitemap.xml`.
- **Most important for local search:** create / verify a Google Business Profile for Media Store in Banha and put the website link on it. That's what makes you show on the map for "شركة تسويق في بنها".

## Language
The site opens in Arabic for Arabic browsers, English otherwise. Visitors switch with the ع / EN button. Force with `?lang=ar` or `?lang=en`.
